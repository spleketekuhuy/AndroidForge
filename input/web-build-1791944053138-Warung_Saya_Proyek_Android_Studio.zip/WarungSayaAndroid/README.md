# Warung Saya — proyek Android

Ini adalah **proyek sumber Android Studio**, bukan APK yang telah dikompilasi. Lingkungan pembuat berkas ini tidak memiliki Android SDK/Gradle terpasang sehingga tidak bisa menghasilkan dan menguji APK final di sini.

## Cara membangun APK
1. Di komputer, instal Android Studio dari situs resmi developer.android.com/studio.
2. Ekstrak ZIP ini.
3. Buka folder `WarungSayaAndroid` melalui Android Studio.
4. Tunggu Gradle sync. Pastikan Android SDK Platform 35 terpasang jika diminta.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan APK ke HP Android, buka file, lalu izinkan pemasangan dari sumber tersebut bila Android meminta.

## Fitur
- Kasir, hitung total dan kembalian.
- Inventaris, harga jual, modal per unit, stok.
- Stok otomatis berkurang ketika transaksi selesai.
- Catatan utang dan cicilan pembayaran.
- Laporan omzet dan perkiraan laba kotor.
- Cetak struk melalui dialog cetak Android.
- Ekspor/impor cadangan JSON.
- Data disimpan lokal di WebView pada perangkat; tidak memerlukan akun atau server.

## Catatan
- Produk dan harga awal hanyalah contoh; ubah melalui menu Barang.
- Data browser lokal dapat hilang bila aplikasi dihapus atau data aplikasi dibersihkan. Ekspor cadangan secara berkala.
- Sebelum dipakai untuk pembukuan penting, uji alur kasir, pemulihan cadangan, dan printer yang akan digunakan.
