/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#1d2c22',
    tint: '#286143',

    // Core surfaces
    background: '#f5f6ef',
    foreground: '#1d2c22',

    // Cards / elevated surfaces
    card: '#ffffff',
    cardForeground: '#1d2c22',

    // Primary action color (buttons, links, active states)
    primary: '#286143',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#e9efe5',
    secondaryForeground: '#31513a',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#edf0e9',
    mutedForeground: '#748076',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#f5ead4',
    accentForeground: '#8a5b1c',

    // Destructive actions (delete, error states)
    destructive: '#c9493d',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#e1e7dc',
    input: '#dce3d8',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 8,
};

export default colors;
