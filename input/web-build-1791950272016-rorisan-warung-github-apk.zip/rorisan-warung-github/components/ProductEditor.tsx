import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useEffect, useState } from 'react';
import {
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import { Category, Product, ProductInput } from '@/context/InventoryContext';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

type ProductEditorProps = {
  visible: boolean;
  product?: Product | null;
  categories: Category[];
  onClose: () => void;
  onSave: (product: ProductInput) => void;
  onManageCategories: () => void;
};

export function ProductEditor({
  visible,
  product,
  categories,
  onClose,
  onSave,
  onManageCategories,
}: ProductEditorProps) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [price, setPrice] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!visible) return;
    setName(product?.name ?? '');
    setQuantity(product ? String(product.quantity) : '');
    setPrice(product ? String(product.price) : '');
    setCategoryId(product?.categoryId ?? categories[0]?.id ?? '');
    setError('');
  }, [visible, product?.id, categories]);

  const handleSave = async () => {
    const trimmedName = name.trim();
    const numericQuantity = Number(quantity);
    const numericPrice = Number(price);

    if (!trimmedName) {
      setError('Nama barang wajib diisi.');
      return;
    }
    if (
      quantity.trim() === '' ||
      !Number.isInteger(numericQuantity) ||
      numericQuantity < 0
    ) {
      setError('Jumlah barang harus berupa angka 0 atau lebih.');
      return;
    }
    if (price.trim() === '' || !Number.isFinite(numericPrice) || numericPrice < 0) {
      setError('Harga harus berupa angka 0 atau lebih.');
      return;
    }
    if (!categories.some((category) => category.id === categoryId)) {
      setError('Pilih kategori untuk barang ini.');
      return;
    }

    onSave({
      name: trimmedName,
      quantity: numericQuantity,
      price: numericPrice,
      categoryId,
    });
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    onClose();
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
      statusBarTranslucent={Platform.OS !== 'web'}
    >
      <View style={[styles.overlay, { backgroundColor: 'rgba(17, 30, 21, 0.38)' }]}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View
          style={[
            styles.sheet,
            {
              backgroundColor: colors.background,
              paddingBottom: Math.max(insets.bottom + 24, Platform.OS === 'web' ? 42 : 24),
              maxHeight: '94%',
            },
          ]}
        >
          <View style={styles.grabber} />
          <View style={styles.sheetHeader}>
            <View>
              <Text style={[styles.title, { color: colors.foreground }]}>
                {product ? 'Ubah barang' : 'Tambah barang'}
              </Text>
              <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
                Lengkapi informasi stok warung Anda.
              </Text>
            </View>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Tutup formulir"
              onPress={onClose}
              style={[styles.closeButton, { backgroundColor: colors.secondary }]}
            >
              <Feather name="x" size={20} color={colors.secondaryForeground} />
            </Pressable>
          </View>

          <KeyboardAwareScrollViewCompat
            contentContainerStyle={styles.formContent}
            keyboardShouldPersistTaps="handled"
            bottomOffset={28}
          >
            <Text style={[styles.label, { color: colors.foreground }]}>Nama barang</Text>
            <TextInput
              testID="product-name-input"
              value={name}
              onChangeText={setName}
              placeholder="Contoh: Beras 5 kg"
              placeholderTextColor={colors.mutedForeground}
              style={[
                styles.input,
                { color: colors.foreground, borderColor: colors.input, backgroundColor: colors.card },
              ]}
              returnKeyType="next"
              maxLength={60}
            />

            <Text style={[styles.label, { color: colors.foreground }]}>Kategori</Text>
            {categories.length > 0 ? (
              <View style={styles.categoryChoices}>
                {categories.map((category) => {
                  const selected = category.id === categoryId;
                  return (
                    <Pressable
                      key={category.id}
                      accessibilityRole="button"
                      accessibilityState={{ selected }}
                      onPress={() => setCategoryId(category.id)}
                      style={[
                        styles.categoryChoice,
                        {
                          backgroundColor: selected ? colors.primary : colors.card,
                          borderColor: selected ? colors.primary : colors.border,
                        },
                      ]}
                    >
                      <Text
                        style={[
                          styles.categoryChoiceText,
                          { color: selected ? colors.primaryForeground : colors.foreground },
                        ]}
                      >
                        {category.name}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
            ) : (
              <Pressable
                onPress={onManageCategories}
                style={[styles.emptyCategory, { backgroundColor: colors.secondary }]}
              >
                <Text style={[styles.emptyCategoryText, { color: colors.secondaryForeground }]}>
                  Buat kategori dahulu
                </Text>
                <Feather name="arrow-right" size={16} color={colors.secondaryForeground} />
              </Pressable>
            )}

            <View style={styles.twoColumns}>
              <View style={styles.column}>
                <Text style={[styles.label, { color: colors.foreground }]}>Jumlah barang</Text>
                <TextInput
                  testID="product-quantity-input"
                  value={quantity}
                  onChangeText={(value) => setQuantity(value.replace(/[^\d]/g, ''))}
                  placeholder="0"
                  placeholderTextColor={colors.mutedForeground}
                  keyboardType="number-pad"
                  style={[
                    styles.input,
                    { color: colors.foreground, borderColor: colors.input, backgroundColor: colors.card },
                  ]}
                />
              </View>
              <View style={styles.column}>
                <Text style={[styles.label, { color: colors.foreground }]}>Harga barang (Rp)</Text>
                <TextInput
                  testID="product-price-input"
                  value={price}
                  onChangeText={(value) => setPrice(value.replace(/[^\d]/g, ''))}
                  placeholder="0"
                  placeholderTextColor={colors.mutedForeground}
                  keyboardType="number-pad"
                  style={[
                    styles.input,
                    { color: colors.foreground, borderColor: colors.input, backgroundColor: colors.card },
                  ]}
                />
              </View>
            </View>

            {!!error && (
              <Text accessibilityRole="alert" style={[styles.error, { color: colors.destructive }]}>
                {error}
              </Text>
            )}
            <Pressable
              testID="save-product-button"
              accessibilityRole="button"
              onPress={handleSave}
              disabled={categories.length === 0}
              style={[
                styles.saveButton,
                { backgroundColor: categories.length === 0 ? colors.muted : colors.primary },
              ]}
            >
              <Text
                style={[
                  styles.saveText,
                  { color: categories.length === 0 ? colors.mutedForeground : colors.primaryForeground },
                ]}
              >
                {product ? 'Simpan perubahan' : 'Simpan barang'}
              </Text>
            </Pressable>
          </KeyboardAwareScrollViewCompat>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  sheet: {
    width: '100%',
    maxWidth: 560,
    alignSelf: 'center',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingTop: 10,
    paddingHorizontal: 22,
  },
  grabber: {
    width: 38,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#cbd3c8',
    alignSelf: 'center',
    marginBottom: 18,
  },
  sheetHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  title: {
    fontSize: 23,
    lineHeight: 29,
    fontFamily: 'Inter_700Bold',
  },
  subtitle: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    marginTop: 4,
  },
  closeButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
  },
  formContent: {
    paddingBottom: 8,
  },
  label: {
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
    marginBottom: 8,
    marginTop: 2,
  },
  input: {
    minHeight: 50,
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 15,
    fontSize: 15,
    fontFamily: 'Inter_400Regular',
    marginBottom: 20,
  },
  categoryChoices: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 20,
  },
  categoryChoice: {
    borderWidth: 1,
    borderRadius: 18,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  categoryChoiceText: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
  },
  emptyCategory: {
    minHeight: 48,
    paddingHorizontal: 14,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
    marginBottom: 20,
  },
  emptyCategoryText: {
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
  },
  twoColumns: {
    flexDirection: 'row',
    gap: 12,
  },
  column: {
    flex: 1,
  },
  error: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
    marginTop: -6,
    marginBottom: 14,
  },
  saveButton: {
    minHeight: 54,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
  },
  saveText: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
  },
});
