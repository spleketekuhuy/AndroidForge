# Rorisan Warung — paket build APK Android

Paket ini berisi aplikasi Rorisan Warung dan workflow GitHub Actions untuk
menghasilkan APK debug yang bisa dipasang langsung di perangkat Android.

## Cara membuat APK

1. Ekstrak ZIP ini di komputer.
2. Buat repository kosong di GitHub.
3. Buka terminal di folder hasil ekstrak dan jalankan perintah berikut. Ganti
   `USERNAME/NAMA-REPO` dengan pemilik dan nama repository GitHub Anda.

   ```sh
   git init
   git add .
   git commit -m "Rorisan Warung Android"
   git branch -M main
   git remote add origin https://github.com/USERNAME/NAMA-REPO.git
   git push -u origin main
   ```

   Perintah `git add .` menyertakan workflow tersembunyi di `.github`.
4. Buka tab **Actions** di repository GitHub.
5. Pilih workflow **Build Android APK**, lalu tekan **Run workflow**.
6. Setelah workflow selesai, buka ringkasan run dan unduh artifact
   **rorisan-warung-debug-apk**.
7. Ekstrak ZIP artifact yang diunduh untuk mendapatkan `app-debug.apk`.
8. Pindahkan APK ke ponsel Android dan buka file tersebut untuk memasang aplikasi.
   Android mungkin meminta izin untuk memasang aplikasi dari sumber ini.

## Catatan

- Build APK dilakukan di GitHub Actions; Replit tidak membangun APK.
- APK ini adalah build debug untuk uji coba dan pemasangan langsung, bukan paket
  yang siap dipublikasikan ke Google Play.
- Aplikasi menyimpan data barang secara lokal di perangkat.
