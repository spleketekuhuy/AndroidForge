import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ProductEditor } from '@/components/ProductEditor';
import {
  Product,
  ProductInput,
  useInventory,
} from '@/context/InventoryContext';
import { useColors } from '@/hooks/useColors';

const formatRupiah = (amount: number) =>
  `Rp${new Intl.NumberFormat('id-ID', { maximumFractionDigits: 0 }).format(amount)}`;

export default function InventoryScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const {
    categories,
    products,
    isReady,
    persistenceError,
    addProduct,
    updateProduct,
    deleteProduct,
  } = useInventory();
  const [query, setQuery] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState('all');
  const [editorVisible, setEditorVisible] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const activeCategoryId =
    selectedCategoryId === 'all' ||
    categories.some((category) => category.id === selectedCategoryId)
      ? selectedCategoryId
      : 'all';

  const visibleProducts = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase('id');
    return products.filter((product) => {
      const matchesCategory =
        activeCategoryId === 'all' || product.categoryId === activeCategoryId;
      const matchesSearch =
        normalizedQuery.length === 0 ||
        product.name.toLocaleLowerCase('id').includes(normalizedQuery);
      return matchesCategory && matchesSearch;
    });
  }, [activeCategoryId, products, query]);

  const totalStockUnits = products.reduce(
    (total, product) => total + product.quantity,
    0,
  );
  const stockValue = products.reduce(
    (total, product) => total + product.quantity * product.price,
    0,
  );
  const topInset = Platform.OS === 'web' ? Math.max(67, insets.top) : insets.top;

  const openNewProduct = () => {
    setEditingProduct(null);
    setEditorVisible(true);
  };

  const openEditor = (product: Product) => {
    setEditingProduct(product);
    setEditorVisible(true);
  };

  const handleSave = (input: ProductInput) => {
    if (editingProduct) {
      updateProduct({ ...editingProduct, ...input });
    } else {
      addProduct(input);
    }
  };

  const handleDelete = (product: Product) => {
    Alert.alert(
      'Hapus barang?',
      `Barang “${product.name}” akan dihapus dari daftar stok.`,
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Hapus',
          style: 'destructive',
          onPress: () => {
            deleteProduct(product.id);
            void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          },
        },
      ],
    );
  };

  const renderProduct = ({ item }: { item: Product }) => {
    const category = categories.find((entry) => entry.id === item.categoryId);
    const lowStock = item.quantity <= 5;

    return (
      <View
        style={[
          styles.productCard,
          { backgroundColor: colors.card, borderColor: colors.border },
        ]}
      >
        <View style={styles.productTop}>
          <View style={styles.productNameBlock}>
            <Text style={[styles.productName, { color: colors.foreground }]}>
              {item.name}
            </Text>
            <View
              style={[
                styles.categoryLabel,
                { backgroundColor: colors.secondary },
              ]}
            >
              <Text
                numberOfLines={1}
                style={[
                  styles.categoryLabelText,
                  { color: colors.secondaryForeground },
                ]}
              >
                {category?.name ?? 'Tanpa kategori'}
              </Text>
            </View>
          </View>
          <View style={styles.rowActions}>
            <Pressable
              testID={`edit-product-${item.id}`}
              accessibilityRole="button"
              accessibilityLabel={`Ubah ${item.name}`}
              onPress={() => openEditor(item)}
              hitSlop={8}
              style={[styles.iconButton, { backgroundColor: colors.secondary }]}
            >
              <Feather name="edit-2" size={15} color={colors.secondaryForeground} />
            </Pressable>
            <Pressable
              testID={`delete-product-${item.id}`}
              accessibilityRole="button"
              accessibilityLabel={`Hapus ${item.name}`}
              onPress={() => handleDelete(item)}
              hitSlop={8}
              style={[styles.iconButton, { backgroundColor: colors.muted }]}
            >
              <Feather name="trash-2" size={15} color={colors.mutedForeground} />
            </Pressable>
          </View>
        </View>
        <View style={[styles.productDivider, { backgroundColor: colors.border }]} />
        <View style={styles.productDetails}>
          <View>
            <Text style={[styles.detailCaption, { color: colors.mutedForeground }]}>
              Jumlah barang
            </Text>
            <Text
              style={[
                styles.detailValue,
                { color: lowStock ? colors.accentForeground : colors.foreground },
              ]}
            >
              {item.quantity} <Text style={styles.unitLabel}>stok</Text>
            </Text>
          </View>
          <View style={styles.priceBlock}>
            <Text style={[styles.detailCaption, { color: colors.mutedForeground }]}>
              Harga barang
            </Text>
            <Text style={[styles.detailValue, { color: colors.primary }]}>
              {formatRupiah(item.price)}
            </Text>
          </View>
        </View>
      </View>
    );
  };

  const listHeader = (
    <View style={styles.headerContent}>
      <View style={styles.brandRow}>
        <View style={[styles.brandIcon, { backgroundColor: colors.primary }]}>
          <Feather name="shopping-bag" size={20} color={colors.primaryForeground} />
        </View>
        <View style={styles.brandCopy}>
          <Text style={[styles.brandTitle, { color: colors.foreground }]}>
            Rorisan Warung
          </Text>
          <Text style={[styles.brandSubtitle, { color: colors.mutedForeground }]}>
            Catatan stok harian
          </Text>
        </View>
        <View style={[styles.openBadge, { backgroundColor: colors.accent }]}>
          <View style={[styles.openDot, { backgroundColor: colors.accentForeground }]} />
          <Text style={[styles.openText, { color: colors.accentForeground }]}>
            Warung
          </Text>
        </View>
      </View>

      <View style={styles.welcomeBlock}>
        <Text style={[styles.pageTitle, { color: colors.foreground }]}>
          Stok barang
        </Text>
        <Text style={[styles.pageSubtitle, { color: colors.mutedForeground }]}>
          Semua barang warung, tercatat rapi.
        </Text>
      </View>

      <View style={[styles.summaryCard, { backgroundColor: colors.primary }]}>
        <View style={styles.summaryTop}>
          <Text style={styles.summaryEyebrow}>TOTAL HARGA SEMUA BARANG</Text>
          <View style={styles.summaryIcon}>
            <Feather name="archive" size={17} color={colors.primaryForeground} />
          </View>
        </View>
        <Text style={styles.stockValue}>{formatRupiah(stockValue)}</Text>
        <Text style={styles.summaryFormula}>Jumlah stok × harga barang</Text>
        <View style={styles.summaryFooter}>
          <Text style={styles.summaryCount}>
            {products.length} jenis barang
          </Text>
          <View style={styles.summaryDot} />
          <Text style={styles.summaryCount}>{totalStockUnits} barang tersedia</Text>
        </View>
      </View>

      {persistenceError && (
        <View style={[styles.storageWarning, { backgroundColor: colors.accent }]}>
          <Feather name="alert-circle" size={16} color={colors.accentForeground} />
          <Text style={[styles.storageWarningText, { color: colors.accentForeground }]}>
            Penyimpanan perangkat bermasalah. Periksa ruang penyimpanan Anda.
          </Text>
        </View>
      )}

      <View style={styles.sectionHeading}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          Daftar barang
        </Text>
        <Text style={[styles.itemCount, { color: colors.mutedForeground }]}>
          {visibleProducts.length} barang
        </Text>
      </View>

      <View
        style={[
          styles.searchBox,
          { backgroundColor: colors.card, borderColor: colors.border },
        ]}
      >
        <Feather name="search" size={18} color={colors.mutedForeground} />
        <TextInput
          testID="product-search-input"
          value={query}
          onChangeText={setQuery}
          placeholder="Cari nama barang"
          placeholderTextColor={colors.mutedForeground}
          returnKeyType="search"
          style={[styles.searchInput, { color: colors.foreground }]}
        />
        {query.length > 0 && (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Hapus pencarian"
            onPress={() => setQuery('')}
          >
            <Feather name="x-circle" size={18} color={colors.mutedForeground} />
          </Pressable>
        )}
      </View>

      <FlatList
        horizontal
        data={[
          { id: 'all', name: 'Semua' },
          ...categories,
        ]}
        keyExtractor={(item) => item.id}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.categoryFilterList}
        renderItem={({ item }) => {
          const selected = activeCategoryId === item.id;
          return (
            <Pressable
              testID={`filter-category-${item.id}`}
              accessibilityRole="button"
              accessibilityState={{ selected }}
              onPress={() => setSelectedCategoryId(item.id)}
              style={[
                styles.filterChip,
                {
                  backgroundColor: selected ? colors.primary : colors.card,
                  borderColor: selected ? colors.primary : colors.border,
                },
              ]}
            >
              <Text
                style={[
                  styles.filterChipText,
                  { color: selected ? colors.primaryForeground : colors.foreground },
                ]}
              >
                {item.name}
              </Text>
            </Pressable>
          );
        }}
      />
    </View>
  );

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      {!isReady ? (
        <View style={[styles.loading, { paddingTop: topInset }]}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : (
        <>
          <FlatList
            data={visibleProducts}
            keyExtractor={(item) => item.id}
            renderItem={renderProduct}
            ListHeaderComponent={listHeader}
            ListEmptyComponent={
              <View style={[styles.emptyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
                  <Feather
                    name={query || activeCategoryId !== 'all' ? 'search' : 'package'}
                    size={22}
                    color={colors.primary}
                  />
                </View>
                <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
                  {products.length === 0
                    ? 'Belum ada barang'
                    : 'Barang tidak ditemukan'}
                </Text>
                <Text style={[styles.emptyCopy, { color: colors.mutedForeground }]}>
                  {products.length === 0
                    ? 'Mulai catat barang dan stok warung Anda di sini.'
                    : 'Coba kata kunci atau kategori yang berbeda.'}
                </Text>
              </View>
            }
            contentContainerStyle={{
              paddingTop: topInset + 12,
              paddingHorizontal: 20,
              paddingBottom: Platform.OS === 'web' ? 158 : insets.bottom + 132,
              flexGrow: 1,
            }}
            keyboardShouldPersistTaps="handled"
            keyboardDismissMode="on-drag"
          />
          <Pressable
            testID="add-product-button"
            accessibilityRole="button"
            onPress={openNewProduct}
            style={[
              styles.addButton,
              {
                backgroundColor: colors.primary,
                bottom: Platform.OS === 'web' ? 108 : insets.bottom + 90,
              },
            ]}
          >
            <Feather name="plus" size={20} color={colors.primaryForeground} />
            <Text style={[styles.addButtonText, { color: colors.primaryForeground }]}>
              Tambah barang
            </Text>
          </Pressable>
        </>
      )}

      <ProductEditor
        visible={editorVisible}
        product={editingProduct}
        categories={categories}
        onClose={() => setEditorVisible(false)}
        onSave={handleSave}
        onManageCategories={() => {
          setEditorVisible(false);
          router.push('/(tabs)/categories');
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  loading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerContent: {
    marginBottom: 4,
  },
  brandRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 29,
  },
  brandIcon: {
    width: 40,
    height: 40,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 11,
  },
  brandCopy: {
    flex: 1,
  },
  brandTitle: {
    fontSize: 15,
    fontFamily: 'Inter_700Bold',
    letterSpacing: -0.2,
  },
  brandSubtitle: {
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    marginTop: 2,
  },
  openBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 7,
    gap: 6,
  },
  openDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  openText: {
    fontSize: 11,
    fontFamily: 'Inter_600SemiBold',
  },
  welcomeBlock: {
    marginBottom: 17,
  },
  pageTitle: {
    fontSize: 27,
    lineHeight: 33,
    fontFamily: 'Inter_700Bold',
    letterSpacing: -0.8,
  },
  pageSubtitle: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    marginTop: 5,
  },
  summaryCard: {
    minHeight: 154,
    borderRadius: 22,
    padding: 19,
    marginBottom: 26,
  },
  summaryTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  summaryEyebrow: {
    color: 'rgba(255,255,255,0.72)',
    fontSize: 10,
    fontFamily: 'Inter_600SemiBold',
    letterSpacing: 1,
  },
  summaryIcon: {
    width: 30,
    height: 30,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.16)',
  },
  stockValue: {
    color: '#fffef8',
    fontSize: 27,
    lineHeight: 34,
    fontFamily: 'Inter_700Bold',
    letterSpacing: -0.7,
    marginTop: 12,
  },
  summaryFormula: {
    color: 'rgba(255,255,255,0.72)',
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
    marginTop: 1,
  },
  summaryFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    gap: 8,
  },
  summaryCount: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
  },
  summaryDot: {
    width: 3,
    height: 3,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.6)',
  },
  storageWarning: {
    flexDirection: 'row',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 11,
    alignItems: 'center',
    gap: 8,
    marginBottom: 18,
  },
  storageWarningText: {
    flex: 1,
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
  },
  sectionHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 13,
  },
  sectionTitle: {
    fontSize: 17,
    fontFamily: 'Inter_700Bold',
    letterSpacing: -0.3,
  },
  itemCount: {
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
  },
  searchBox: {
    minHeight: 47,
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 13,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 9,
  },
  searchInput: {
    flex: 1,
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    minHeight: 44,
  },
  categoryFilterList: {
    gap: 8,
    paddingBottom: 14,
  },
  filterChip: {
    borderWidth: 1,
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 9,
  },
  filterChipText: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
  },
  productCard: {
    borderWidth: 1,
    borderRadius: 17,
    paddingHorizontal: 15,
    paddingVertical: 14,
    marginBottom: 10,
  },
  productTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  productNameBlock: {
    flex: 1,
    gap: 7,
  },
  productName: {
    fontSize: 15,
    lineHeight: 20,
    fontFamily: 'Inter_600SemiBold',
  },
  categoryLabel: {
    alignSelf: 'flex-start',
    borderRadius: 9,
    paddingHorizontal: 9,
    paddingVertical: 4,
    maxWidth: 150,
  },
  categoryLabelText: {
    fontSize: 10,
    fontFamily: 'Inter_500Medium',
  },
  rowActions: {
    flexDirection: 'row',
    gap: 7,
  },
  iconButton: {
    height: 31,
    width: 31,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  productDivider: {
    height: 1,
    marginVertical: 13,
  },
  productDetails: {
    flexDirection: 'row',
    alignItems: 'flex-end',
  },
  priceBlock: {
    alignItems: 'flex-end',
    marginLeft: 'auto',
  },
  detailCaption: {
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 14,
    fontFamily: 'Inter_700Bold',
  },
  unitLabel: {
    fontSize: 10,
    fontFamily: 'Inter_500Medium',
  },
  emptyCard: {
    borderRadius: 18,
    borderWidth: 1,
    paddingHorizontal: 24,
    paddingVertical: 27,
    alignItems: 'center',
    marginTop: 1,
  },
  emptyIcon: {
    width: 46,
    height: 46,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  emptyTitle: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
  },
  emptyCopy: {
    fontSize: 12,
    lineHeight: 18,
    textAlign: 'center',
    fontFamily: 'Inter_400Regular',
    marginTop: 6,
    maxWidth: 250,
  },
  addButton: {
    position: 'absolute',
    left: 20,
    right: 20,
    minHeight: 54,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 9,
    maxWidth: 520,
    alignSelf: 'center',
    elevation: 4,
    shadowColor: '#14291a',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.16,
    shadowRadius: 10,
  },
  addButtonText: {
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
  },
});
