import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useState } from 'react';
import {
  Alert,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import {
  Category,
  useInventory,
} from '@/context/InventoryContext';
import { useColors } from '@/hooks/useColors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

function CategoryEditor({
  visible,
  category,
  existingNames,
  onClose,
  onSave,
}: {
  visible: boolean;
  category: Category | null;
  existingNames: string[];
  onClose: () => void;
  onSave: (name: string) => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  React.useEffect(() => {
    if (visible) {
      setName(category?.name ?? '');
      setError('');
    }
  }, [visible, category?.id]);

  const save = async () => {
    const normalizedName = name.trim();
    if (!normalizedName) {
      setError('Masukkan nama kategori.');
      return;
    }
    const normalized = normalizedName.toLocaleLowerCase('id');
    const currentName = category?.name.toLocaleLowerCase('id');
    const duplicate = existingNames.some(
      (existing) =>
        existing.toLocaleLowerCase('id') === normalized &&
        existing.toLocaleLowerCase('id') !== currentName,
    );
    if (duplicate) {
      setError('Nama kategori ini sudah digunakan.');
      return;
    }
    onSave(normalizedName);
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    onClose();
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
      statusBarTranslucent={Platform.OS !== 'web'}
    >
      <View style={[styles.modalOverlay, { backgroundColor: 'rgba(17, 30, 21, 0.38)' }]}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View
          style={[
            styles.editorSheet,
            {
              backgroundColor: colors.background,
              paddingBottom: Math.max(insets.bottom + 24, Platform.OS === 'web' ? 42 : 24),
            },
          ]}
        >
          <View style={styles.grabber} />
          <View style={styles.editorHeader}>
            <View>
              <Text style={[styles.editorTitle, { color: colors.foreground }]}>
                {category ? 'Ubah kategori' : 'Kategori baru'}
              </Text>
              <Text style={[styles.editorSubtitle, { color: colors.mutedForeground }]}>
                Kelompokkan barang sesuai kebutuhan warung.
              </Text>
            </View>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Tutup formulir kategori"
              onPress={onClose}
              style={[styles.closeButton, { backgroundColor: colors.secondary }]}
            >
              <Feather name="x" size={20} color={colors.secondaryForeground} />
            </Pressable>
          </View>
          <KeyboardAwareScrollViewCompat
            contentContainerStyle={styles.editorContent}
            keyboardShouldPersistTaps="handled"
            bottomOffset={24}
          >
            <Text style={[styles.label, { color: colors.foreground }]}>Nama kategori</Text>
            <TextInput
              testID="category-name-input"
              autoFocus
              value={name}
              onChangeText={setName}
              placeholder="Contoh: Perlengkapan mandi"
              placeholderTextColor={colors.mutedForeground}
              maxLength={35}
              returnKeyType="done"
              onSubmitEditing={() => void save()}
              style={[
                styles.input,
                { backgroundColor: colors.card, borderColor: colors.input, color: colors.foreground },
              ]}
            />
            {!!error && (
              <Text accessibilityRole="alert" style={[styles.error, { color: colors.destructive }]}>
                {error}
              </Text>
            )}
            <Pressable
              testID="save-category-button"
              accessibilityRole="button"
              onPress={() => void save()}
              style={[styles.saveButton, { backgroundColor: colors.primary }]}
            >
              <Text style={[styles.saveButtonText, { color: colors.primaryForeground }]}>
                {category ? 'Simpan perubahan' : 'Simpan kategori'}
              </Text>
            </Pressable>
          </KeyboardAwareScrollViewCompat>
        </View>
      </View>
    </Modal>
  );
}

export default function CategoriesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    categories,
    products,
    isReady,
    addCategory,
    updateCategory,
    deleteCategory,
  } = useInventory();
  const [editorVisible, setEditorVisible] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const topInset = Platform.OS === 'web' ? Math.max(67, insets.top) : insets.top;

  const openAdd = () => {
    setEditingCategory(null);
    setEditorVisible(true);
  };

  const openEdit = (category: Category) => {
    setEditingCategory(category);
    setEditorVisible(true);
  };

  const handleSave = (name: string) => {
    if (editingCategory) {
      updateCategory(editingCategory.id, name);
    } else {
      addCategory(name);
    }
  };

  const confirmDelete = (category: Category) => {
    const linkedProducts = products.filter(
      (product) => product.categoryId === category.id,
    ).length;
    if (linkedProducts > 0) {
      Alert.alert(
        'Kategori masih digunakan',
        `Pindahkan ${linkedProducts} barang ke kategori lain sebelum menghapus “${category.name}”.`,
        [{ text: 'Mengerti' }],
      );
      return;
    }

    Alert.alert(
      'Hapus kategori?',
      `Kategori “${category.name}” akan dihapus.`,
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Hapus',
          style: 'destructive',
          onPress: () => {
            deleteCategory(category.id);
            void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          },
        },
      ],
    );
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={{
          paddingTop: topInset + 14,
          paddingHorizontal: 21,
          paddingBottom: Platform.OS === 'web' ? 120 : insets.bottom + 100,
        }}
      >
        <View style={styles.brandRow}>
          <View style={[styles.brandIcon, { backgroundColor: colors.primary }]}>
            <Feather name="shopping-bag" size={20} color={colors.primaryForeground} />
          </View>
          <View>
            <Text style={[styles.brandTitle, { color: colors.foreground }]}>
              Rorisan Warung
            </Text>
            <Text style={[styles.brandSubtitle, { color: colors.mutedForeground }]}>
              Pengaturan stok
            </Text>
          </View>
        </View>

        <View style={styles.pageHeading}>
          <View style={styles.headingCopy}>
            <Text style={[styles.pageTitle, { color: colors.foreground }]}>
              Kategori
            </Text>
            <Text style={[styles.pageSubtitle, { color: colors.mutedForeground }]}>
              Atur kelompok barang sesuka Anda.
            </Text>
          </View>
          <View style={[styles.categoryCount, { backgroundColor: colors.secondary }]}>
            <Text style={[styles.countText, { color: colors.secondaryForeground }]}>
              {categories.length}
            </Text>
          </View>
        </View>

        <Pressable
          testID="add-category-button"
          accessibilityRole="button"
          onPress={openAdd}
          disabled={!isReady}
          style={[styles.addCategoryButton, { backgroundColor: colors.primary }]}
        >
          <Feather name="plus" size={18} color={colors.primaryForeground} />
          <Text style={[styles.addCategoryText, { color: colors.primaryForeground }]}>
            Tambah kategori
          </Text>
        </Pressable>

        <View style={styles.sectionHeading}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            Kategori Anda
          </Text>
          <Text style={[styles.sectionCount, { color: colors.mutedForeground }]}>
            {categories.length} kategori
          </Text>
        </View>

        {!isReady ? (
          <View style={styles.loading}>
            <Text style={[styles.emptyCopy, { color: colors.mutedForeground }]}>
              Memuat kategori…
            </Text>
          </View>
        ) : categories.length > 0 ? (
          <View style={styles.categoryList}>
            {categories.map((category, index) => {
              const count = products.filter(
                (product) => product.categoryId === category.id,
              ).length;
              const colorChoices = [
                colors.primary,
                colors.accentForeground,
                colors.tint,
                colors.destructive,
              ];
              const categoryColor = colorChoices[index % colorChoices.length];
              return (
                <View
                  key={category.id}
                  style={[
                    styles.categoryRow,
                    { backgroundColor: colors.card, borderColor: colors.border },
                  ]}
                >
                  <View style={[styles.categoryMark, { backgroundColor: colors.secondary }]}>
                    <View style={[styles.categoryDot, { backgroundColor: categoryColor }]} />
                  </View>
                  <View style={styles.categoryDetails}>
                    <Text style={[styles.categoryName, { color: colors.foreground }]}>
                      {category.name}
                    </Text>
                    <Text style={[styles.productCount, { color: colors.mutedForeground }]}>
                      {count} barang
                    </Text>
                  </View>
                  <Pressable
                    testID={`edit-category-${category.id}`}
                    accessibilityRole="button"
                    accessibilityLabel={`Ubah kategori ${category.name}`}
                    onPress={() => openEdit(category)}
                    hitSlop={8}
                    style={[styles.rowAction, { backgroundColor: colors.secondary }]}
                  >
                    <Feather name="edit-2" size={15} color={colors.secondaryForeground} />
                  </Pressable>
                  <Pressable
                    testID={`delete-category-${category.id}`}
                    accessibilityRole="button"
                    accessibilityLabel={`Hapus kategori ${category.name}`}
                    onPress={() => confirmDelete(category)}
                    hitSlop={8}
                    style={[styles.rowAction, { backgroundColor: colors.muted }]}
                  >
                    <Feather name="trash-2" size={15} color={colors.mutedForeground} />
                  </Pressable>
                </View>
              );
            })}
          </View>
        ) : (
          <View style={[styles.emptyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="tag" size={22} color={colors.primary} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              Belum ada kategori
            </Text>
            <Text style={[styles.emptyCopy, { color: colors.mutedForeground }]}>
              Buat kategori pertama agar barang lebih mudah dikelompokkan.
            </Text>
          </View>
        )}

        <View style={[styles.tipCard, { backgroundColor: colors.accent }]}>
          <Feather name="info" size={17} color={colors.accentForeground} />
          <Text style={[styles.tipText, { color: colors.accentForeground }]}>
            Barang di dalam kategori harus dipindahkan dulu sebelum kategorinya bisa dihapus.
          </Text>
        </View>
      </ScrollView>

      <CategoryEditor
        visible={editorVisible}
        category={editingCategory}
        existingNames={categories.map((category) => category.name)}
        onClose={() => setEditorVisible(false)}
        onSave={handleSave}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  brandRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 31,
  },
  brandIcon: {
    width: 40,
    height: 40,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 11,
  },
  brandTitle: {
    fontSize: 15,
    fontFamily: 'Inter_700Bold',
  },
  brandSubtitle: {
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    marginTop: 2,
  },
  pageHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headingCopy: {
    flex: 1,
  },
  pageTitle: {
    fontSize: 27,
    lineHeight: 33,
    fontFamily: 'Inter_700Bold',
    letterSpacing: -0.8,
  },
  pageSubtitle: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    marginTop: 5,
  },
  categoryCount: {
    width: 38,
    height: 38,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  countText: {
    fontSize: 15,
    fontFamily: 'Inter_700Bold',
  },
  addCategoryButton: {
    height: 51,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 15,
    gap: 8,
    marginBottom: 28,
  },
  addCategoryText: {
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
  },
  sectionHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 13,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: 'Inter_700Bold',
  },
  sectionCount: {
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
  },
  categoryList: {
    gap: 9,
  },
  categoryRow: {
    minHeight: 70,
    borderWidth: 1,
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 11,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
  },
  categoryMark: {
    width: 40,
    height: 40,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryDot: {
    width: 11,
    height: 11,
    borderRadius: 6,
  },
  categoryDetails: {
    flex: 1,
    gap: 4,
  },
  categoryName: {
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
  },
  productCount: {
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
  },
  rowAction: {
    width: 33,
    height: 33,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyCard: {
    borderWidth: 1,
    borderRadius: 17,
    paddingHorizontal: 24,
    paddingVertical: 25,
    alignItems: 'center',
  },
  emptyIcon: {
    width: 45,
    height: 45,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 11,
  },
  emptyTitle: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
  },
  emptyCopy: {
    fontSize: 12,
    lineHeight: 18,
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
    maxWidth: 250,
    marginTop: 6,
  },
  loading: {
    minHeight: 150,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tipCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 13,
    marginTop: 19,
  },
  tipText: {
    flex: 1,
    fontSize: 11,
    lineHeight: 17,
    fontFamily: 'Inter_500Medium',
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  editorSheet: {
    width: '100%',
    maxWidth: 560,
    alignSelf: 'center',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingTop: 10,
    paddingHorizontal: 22,
  },
  grabber: {
    width: 38,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#cbd3c8',
    alignSelf: 'center',
    marginBottom: 18,
  },
  editorHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 23,
  },
  editorTitle: {
    fontSize: 22,
    lineHeight: 28,
    fontFamily: 'Inter_700Bold',
  },
  editorSubtitle: {
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    marginTop: 4,
  },
  closeButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
  },
  editorContent: {
    paddingBottom: 6,
  },
  label: {
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
    marginBottom: 8,
  },
  input: {
    minHeight: 50,
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 15,
    fontSize: 15,
    fontFamily: 'Inter_400Regular',
    marginBottom: 14,
  },
  error: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
    marginBottom: 12,
  },
  saveButton: {
    minHeight: 52,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
  },
  saveButtonText: {
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
  },
});
