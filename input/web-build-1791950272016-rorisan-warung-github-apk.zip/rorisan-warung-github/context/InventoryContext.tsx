import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

export type Category = {
  id: string;
  name: string;
};

export type Product = {
  id: string;
  name: string;
  quantity: number;
  price: number;
  categoryId: string;
};

export type ProductInput = Omit<Product, 'id'>;

type InventoryData = {
  categories: Category[];
  products: Product[];
};

type InventoryContextValue = InventoryData & {
  isReady: boolean;
  persistenceError: boolean;
  addProduct: (product: ProductInput) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
  addCategory: (name: string) => void;
  updateCategory: (id: string, name: string) => void;
  deleteCategory: (id: string) => void;
};

const STORAGE_KEY = '@rorisan-warung/inventory-v1';

const INITIAL_DATA: InventoryData = {
  categories: [
    { id: 'cat-sembako', name: 'Sembako' },
    { id: 'cat-minuman', name: 'Minuman' },
    { id: 'cat-camilan', name: 'Camilan' },
  ],
  products: [],
};

const InventoryContext = createContext<InventoryContextValue | null>(null);

function createId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function isInventoryData(value: unknown): value is InventoryData {
  if (!value || typeof value !== 'object') return false;
  const candidate = value as Partial<InventoryData>;
  return (
    Array.isArray(candidate.categories) &&
    Array.isArray(candidate.products) &&
    candidate.categories.every(
      (category) =>
        typeof category.id === 'string' && typeof category.name === 'string',
    ) &&
    candidate.products.every(
      (product) =>
        typeof product.id === 'string' &&
        typeof product.name === 'string' &&
        typeof product.quantity === 'number' &&
        typeof product.price === 'number' &&
        typeof product.categoryId === 'string',
    )
  );
}

export function InventoryProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [data, setData] = useState<InventoryData>(INITIAL_DATA);
  const [isReady, setIsReady] = useState(false);
  const [persistenceError, setPersistenceError] = useState(false);
  const writeQueue = useRef<Promise<void>>(Promise.resolve());

  useEffect(() => {
    let cancelled = false;

    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (!cancelled && stored) {
          const parsed: unknown = JSON.parse(stored);
          if (isInventoryData(parsed)) {
            setData(parsed);
          } else {
            setPersistenceError(true);
          }
        }
      })
      .catch(() => {
        if (!cancelled) setPersistenceError(true);
      })
      .finally(() => {
        if (!cancelled) setIsReady(true);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!isReady) return;

    const snapshot = JSON.stringify(data);
    writeQueue.current = writeQueue.current
      .catch(() => undefined)
      .then(() => AsyncStorage.setItem(STORAGE_KEY, snapshot))
      .catch(() => {
        setPersistenceError(true);
      });
  }, [data, isReady]);

  const addProduct = useCallback((product: ProductInput) => {
    setData((current) => ({
      ...current,
      products: [{ ...product, id: createId() }, ...current.products],
    }));
  }, []);

  const updateProduct = useCallback((product: Product) => {
    setData((current) => ({
      ...current,
      products: current.products.map((item) =>
        item.id === product.id ? product : item,
      ),
    }));
  }, []);

  const deleteProduct = useCallback((id: string) => {
    setData((current) => ({
      ...current,
      products: current.products.filter((item) => item.id !== id),
    }));
  }, []);

  const addCategory = useCallback((name: string) => {
    setData((current) => ({
      ...current,
      categories: [...current.categories, { id: createId(), name }],
    }));
  }, []);

  const updateCategory = useCallback((id: string, name: string) => {
    setData((current) => ({
      ...current,
      categories: current.categories.map((category) =>
        category.id === id ? { ...category, name } : category,
      ),
    }));
  }, []);

  const deleteCategory = useCallback((id: string) => {
    setData((current) => ({
      ...current,
      categories: current.categories.filter((category) => category.id !== id),
    }));
  }, []);

  const value = useMemo(
    () => ({
      ...data,
      isReady,
      persistenceError,
      addProduct,
      updateProduct,
      deleteProduct,
      addCategory,
      updateCategory,
      deleteCategory,
    }),
    [
      data,
      isReady,
      persistenceError,
      addProduct,
      updateProduct,
      deleteProduct,
      addCategory,
      updateCategory,
      deleteCategory,
    ],
  );

  return (
    <InventoryContext.Provider value={value}>
      {children}
    </InventoryContext.Provider>
  );
}

export function useInventory() {
  const context = useContext(InventoryContext);
  if (!context) {
    throw new Error('useInventory must be used inside InventoryProvider.');
  }
  return context;
}
